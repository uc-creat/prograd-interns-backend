package com.proGrad.ArtGallery.controller;

import com.proGrad.ArtGallery.entity.UserEntity;
import com.proGrad.ArtGallery.service.LoginService;
import org.apache.catalina.User;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/login")
public class LoginController {

    private final LoginService loginService;

    public LoginController(LoginService loginService) {
        this.loginService = loginService;
    }

    @GetMapping
    public List<UserEntity> findAllUsers()
    {
        return loginService.findAllUsers();
    }

    @GetMapping("/{id}")
    public Optional<UserEntity> findById(@PathVariable("id") Long id)
    {
        return loginService.findById(id);
    }

//    @GetMapping("/{emailId}")
//    public Optional<UserEntity> findByEmailId(@PathVariable("emailId") String emailId)
//    {
//        return loginService.findByEmail(emailId);
//    }

    @PostMapping
    public UserEntity saveUser(@RequestBody UserEntity userEntity1)
    {
        return loginService.saveUser(userEntity1);
    }




//    @PostMapping("/login1")
//    public String check(@RequestBody UserEntity userEntity)
//    {
//        UserEntity authenticated=loginService.authenticate(userEntity.getEmailId(),userEntity.getPassword());
//        if(authenticated!=null)
//        {
//            return "Logged in Succesfully";
//        }
//        else {
//            return "Do signup first";
//        }
//    }

//    @PostMapping
//    public UserEntity validate(@RequestBody UserEntity userEntity2)
//    {
//        if (userEntity2.getEmailId()=)
//    }

}

